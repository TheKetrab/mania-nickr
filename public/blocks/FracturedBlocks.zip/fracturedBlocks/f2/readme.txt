Fractured Block f2 by dragere
This model is made in Blender with the addon "Object: Cell Fracture".

total number of vertices: 	1 574
total number of faces:		  894
There are low numbers, there should be no problem!

When scaling lighting errors may occur.
For consistent results place the blocks in dynamic mode.