Low Quality Tree JapaneseMaple by dragere
This model is made in Blender with the addon "Add Curve: Sapling Tree Gen".

total number of vertices: 	7 936 (HQ: 107 228)x
total number of faces:		7 093 (HQ:  93 370)
There are high numbers, so place these blocks with caution!

The material for the wood is StadiumDirt and the material used for the leafes is StadiumGrass.
UVs for such materials are generated internally, which can result in a mess, although it never happened to me with this block. 
For consistent results place the blocks in dynamic mode.