Low Quality Tree Callistemon by dragere
This model is made in Blender with the addon "Add Curve: Sapling Tree Gen".

total number of vertices: 	12 028 (HQ: 56 856)
total number of faces:		10 278 (HQ: 52 288)
There are mid numbers, so place these blocks with care!

The material for the wood is StadiumDirt and the material used for the leafes is StadiumGrass.
UVs for such materials are generated internally, which can result in a mess, although it never happened to me with this block. 
For consistent results place the blocks in dynamic mode.