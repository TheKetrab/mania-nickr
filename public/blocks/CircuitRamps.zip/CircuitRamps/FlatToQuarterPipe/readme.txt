FlatToQuarterPipe by dragere
This model is made in Blender.

total number of vertices: 	1 358
total number of faces:		1 356
There are low numbers, there should be no problem!

When scaling lighting errors may occur.
Place the blocks in dynamic mode for consistent results.

This block is designed to work with the road quater pipe,
if you want to use it with the platform quater pipe scale
it by ~1.045 and move it down by ~1.4375.