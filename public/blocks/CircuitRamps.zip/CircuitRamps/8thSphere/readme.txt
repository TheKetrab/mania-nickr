8thSphere by dragere
This model is made in Blender.

total number of vertices: 	6 918
total number of faces:		6 162
There are low/common numbers, there should be no problem!

When scaling lighting errors may occur.
For consistent results place the blocks in dynamic mode.

This block is designed to work with the road quater pipe,
if you want to use it with the platform quater pipe scale
it by ~1.045 and move it down by ~1.4375.