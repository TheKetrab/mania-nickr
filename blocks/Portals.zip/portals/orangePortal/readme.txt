orangePortal by dragere
This model is made in Blender.

total number of vertices: 	4
total number of faces:		1
There are ultra low numbers, there should be no problem concerning performance!

When scaling lighting errors may occur.
For consistent results place the blocks in dynamic mode.

This block has no collsion and only one face, so from the
other side the block will be invisible (even in the editor!).


			INSTALLATION
Place this folder in any subdirectory of ..\Documents\TrackMania\Blocks\
Than place orangePortal.dds in ..\Documents\TrackMania\Blocks\Textures\

Texture source: http://jonvilma.com/portal.html